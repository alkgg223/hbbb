package com.eggsteal;

import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Arena layout: a hub in the middle and 6 bases (3 north, 3 south). */
public class Arena {
    public static final int BASES = 6;
    static final Block[] COLORS = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.GREEN_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.PURPLE_CONCRETE, Blocks.ORANGE_CONCRETE};

    public static int cx(int i) { return (i % 3 - 1) * 50; }
    public static int cz(int i) { return i < 3 ? -32 : 32; }
    /** +1 when the hub is toward +z, -1 when toward -z. */
    public static int dir(int i) { return i < 3 ? 1 : -1; }
    public static int beltZ(int i) { return cz(i) + 9 * dir(i); }
    public static Vec3 home(int i) { return new Vec3(cx(i) + 0.5, 64, cz(i) + 0.5); }

    public static Vec3 slot(int base, int idx) {
        int col = idx % 4, row = idx / 4;
        return new Vec3(cx(base) - 6 + col * 4 + 0.5, 64, cz(base) - dir(base) * (6 - row * 4) + 0.5);
    }

    public static int available(Economy.Stats s) { return Math.min(8, 3 + s.slots); }

    public static int owned(ServerLevel sl, UUID owner) {
        return sl.getEntities(EntityTypeTest.forClass(CreatureEntity.class), c -> owner.equals(c.owner())).size();
    }

    public static int freeSlot(ServerLevel sl, int base, int available) {
        for (int i = 0; i < available; i++) {
            Vec3 p = slot(base, i);
            AABB box = new AABB(p.x - 0.7, p.y - 0.5, p.z - 0.7, p.x + 0.7, p.y + 1.5, p.z + 0.7);
            if (sl.getEntitiesOfClass(CreatureEntity.class, box).isEmpty()) return i;
        }
        return -1;
    }

    public static void spawnCreature(ServerLevel sl, UUID owner, int variant, int base, int idx) {
        Vec3 p = slot(base, idx);
        CreatureEntity ce = EggSteal.CREATURE.get().create(sl);
        if (ce == null) return;
        ce.moveTo(p.x, p.y, p.z, dir(base) > 0 ? 0f : 180f, 0f);
        ce.setVariant(variant);
        ce.setOwner(owner);
        ce.startHatch(60);
        sl.addFreshEntity(ce);
    }

    /** Places a creature in the first free slot. Returns false when the base is full. */
    public static boolean place(ServerLevel sl, UUID owner, int variant, Economy.Stats st) {
        if (st.base < 0) return false;
        int idx = freeSlot(sl, st.base, available(st));
        if (idx < 0) return false;
        spawnCreature(sl, owner, variant, st.base, idx);
        return true;
    }

    public static void rules(MinecraftServer s) {
        s.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false, s);
        s.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false, s);
        s.getGameRules().getRule(GameRules.RULE_WEATHER_CYCLE).set(false, s);
        s.getGameRules().getRule(GameRules.RULE_KEEPINVENTORY).set(true, s);
        s.overworld().setDayTime(6000);
    }

    public static void build(ServerLevel sl) {
        MinecraftServer server = sl.getServer();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = -70; x <= 70; x++)
            for (int z = -50; z <= 50; z++) sl.setBlock(mp.set(x, 63, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
        for (int x = -9; x <= 9; x++)
            for (int z = -9; z <= 9; z++) if (x * x + z * z <= 81) sl.setBlock(mp.set(x, 63, z), (x * x + z * z <= 16 ? Blocks.GOLD_BLOCK : Blocks.SMOOTH_QUARTZ).defaultBlockState(), 2);
        for (int z = -50; z <= 50; z++) for (int x = -1; x <= 1; x++) if (x * x + z * z > 81) sl.setBlock(mp.set(x, 63, z), Blocks.POLISHED_ANDESITE.defaultBlockState(), 2);
        for (int i = 0; i < BASES; i++) {
            int cx = cx(i), cz = cz(i), d = dir(i);
            for (int x = cx - 12; x <= cx + 12; x++)
                for (int z = cz - 12; z <= cz + 12; z++) {
                    boolean edge = Math.abs(x - cx) == 12 || Math.abs(z - cz) == 12;
                    sl.setBlock(mp.set(x, 63, z), (edge ? COLORS[i] : Blocks.POLISHED_ANDESITE).defaultBlockState(), 2);
                }
            for (int s = 0; s < 8; s++) {
                Vec3 p = slot(i, s);
                int px = (int) Math.floor(p.x), pz = (int) Math.floor(p.z);
                for (int x = px - 1; x <= px + 1; x++)
                    for (int z = pz - 1; z <= pz + 1; z++)
                        sl.setBlock(mp.set(x, 63, z), (x == px && z == pz ? Blocks.GOLD_BLOCK : Blocks.WHITE_CONCRETE).defaultBlockState(), 2);
            }
            int bz = beltZ(i);
            for (int x = cx - 10; x <= cx + 10; x++)
                for (int z = bz - 1; z <= bz + 1; z++)
                    sl.setBlock(mp.set(x, 63, z), (z == bz && x % 2 == 0 ? Blocks.YELLOW_CONCRETE : Blocks.BLACK_CONCRETE).defaultBlockState(), 2);
        }
        sl.setBlock(mp.set(0, 64, 6), EggSteal.STATION.get().defaultBlockState(), 2);
        sl.setBlock(mp.set(0, 64, -6), EggSteal.STATION.get().defaultBlockState(), 2);
        for (int cxk = -5; cxk <= 4; cxk++) for (int czk = -4; czk <= 3; czk++) sl.setChunkForced(cxk, czk, true);
        sl.getWorldBorder().setCenter(0, 0);
        sl.getWorldBorder().setSize(150);
        sl.setDefaultSpawnPos(new BlockPos(0, 64, 12), 0f);
        rules(server);
        Hud.cmd(server, "kill @e[type=minecraft:text_display,tag=eggsteal]");
        Hud.summon(server, "es_title", 0, 72, 0, 4f, "§6§lEGG STEAL\n§7Buy eggs, hatch them, steal from others!");
        Hud.summon(server, "es_lb1", -14, 68, 0, 1.6f, "Loading...");
        Hud.summon(server, "es_lb2", 14, 68, 0, 1.6f, "Loading...");
        for (int i = 0; i < BASES; i++) Hud.summon(server, "es_b" + i, cx(i), 68, cz(i), 2f, "Free base");
        Economy.get(server).arenaBuilt = true;
        Economy.get(server).setDirty();
    }
}
