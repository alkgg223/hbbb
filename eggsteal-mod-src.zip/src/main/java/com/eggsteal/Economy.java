package com.eggsteal;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Saved data: money, upgrades and base ownership for every player and bot. */
public class Economy extends SavedData {
    public static class Stats {
        public String name = "?";
        public boolean bot, kit;
        public double money;
        public int speed, income, belt, slots;
        public int base = -1;
    }

    public enum Upgrade {
        SPEED("speed", "Move Speed", 100, 1.8, 20),
        INCOME("income", "Income +15%", 300, 1.9, 30),
        BELT("belt", "Conveyor Belt", 200, 1.8, 20),
        SLOTS("slots", "Base Slots", 500, 3.0, 5);

        public final String id, label;
        public final double base, mult;
        public final int max;

        Upgrade(String id, String label, double base, double mult, int max) {
            this.id = id; this.label = label; this.base = base; this.mult = mult; this.max = max;
        }

        public int level(Stats s) {
            return switch (this) { case SPEED -> s.speed; case INCOME -> s.income; case BELT -> s.belt; case SLOTS -> s.slots; };
        }

        public void set(Stats s, int v) {
            switch (this) { case SPEED -> s.speed = v; case INCOME -> s.income = v; case BELT -> s.belt = v; case SLOTS -> s.slots = v; }
        }

        public double cost(int level) { return Math.floor(base * Math.pow(mult, level)); }

        public static Upgrade byId(String id) {
            for (Upgrade u : values()) if (u.id.equalsIgnoreCase(id)) return u;
            return null;
        }
    }

    public final Map<UUID, Stats> map = new HashMap<>();
    public final UUID[] baseOwner = new UUID[Arena.BASES];
    public boolean arenaBuilt;

    public static Economy get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(Economy::new, Economy::load, null), "eggsteal");
    }

    public Stats stats(UUID id) { return map.computeIfAbsent(id, k -> new Stats()); }

    public int claim(UUID id) {
        Stats s = stats(id);
        if (s.base >= 0) return s.base;
        int b = freeBase();
        if (b >= 0) { baseOwner[b] = id; s.base = b; setDirty(); }
        return b;
    }

    public int freeBase() {
        for (int i = 0; i < Arena.BASES; i++) if (baseOwner[i] == null) return i;
        return -1;
    }

    public void release(UUID id) {
        Stats s = map.remove(id);
        if (s != null && s.base >= 0) baseOwner[s.base] = null;
        setDirty();
    }

    public static double rate(Stats s, Creature c) { return c.income * (1 + 0.15 * s.income); }

    public static String fmt(double v) {
        if (v < 1000) return String.valueOf((long) v);
        String[] u = {"K", "M", "B", "T"};
        int i = -1;
        while (v >= 1000 && i < 3) { v /= 1000; i++; }
        return String.format(Locale.ROOT, "%.1f%s", v, u[i]);
    }

    public static Economy load(CompoundTag tag, HolderLookup.Provider reg) {
        Economy e = new Economy();
        ListTag l = tag.getList("stats", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag t = l.getCompound(i);
            Stats s = new Stats();
            s.name = t.getString("name"); s.bot = t.getBoolean("bot"); s.kit = t.getBoolean("kit");
            s.money = t.getDouble("money"); s.speed = t.getInt("speed"); s.income = t.getInt("income");
            s.belt = t.getInt("belt"); s.slots = t.getInt("slots"); s.base = t.getInt("base");
            e.map.put(t.getUUID("id"), s);
        }
        ListTag b = tag.getList("bases", Tag.TAG_COMPOUND);
        for (int i = 0; i < b.size() && i < Arena.BASES; i++) if (b.getCompound(i).hasUUID("o")) e.baseOwner[i] = b.getCompound(i).getUUID("o");
        e.arenaBuilt = tag.getBoolean("built");
        return e;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider reg) {
        ListTag l = new ListTag();
        for (Map.Entry<UUID, Stats> en : map.entrySet()) {
            CompoundTag t = new CompoundTag();
            Stats s = en.getValue();
            t.putUUID("id", en.getKey());
            t.putString("name", s.name); t.putBoolean("bot", s.bot); t.putBoolean("kit", s.kit);
            t.putDouble("money", s.money); t.putInt("speed", s.speed); t.putInt("income", s.income);
            t.putInt("belt", s.belt); t.putInt("slots", s.slots); t.putInt("base", s.base);
            l.add(t);
        }
        tag.put("stats", l);
        ListTag b = new ListTag();
        for (int i = 0; i < Arena.BASES; i++) {
            CompoundTag t = new CompoundTag();
            if (baseOwner[i] != null) t.putUUID("o", baseOwner[i]);
            b.add(t);
        }
        tag.put("bases", b);
        tag.putBoolean("built", arenaBuilt);
        return tag;
    }
}
