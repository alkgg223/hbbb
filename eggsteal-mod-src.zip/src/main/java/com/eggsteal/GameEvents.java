package com.eggsteal;

import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = EggSteal.MODID)
public class GameEvents {
    static final int BOT_COUNT = 4;
    static final String[] NAMES = {"Zippy", "Bobo", "Nugget", "Pixel", "Mango", "Turbo", "Waffle", "Comet", "Bean", "Ziggy"};

    static boolean inArena(double x, double z) { return Math.abs(x) <= 80 && Math.abs(z) <= 60; }

    @SubscribeEvent
    public static void started(ServerStartedEvent e) {
        if (Economy.get(e.getServer()).arenaBuilt) Arena.rules(e.getServer());
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        MinecraftServer s = p.server;
        ServerLevel sl = s.overworld();
        Economy eco = Economy.get(s);
        if (!eco.arenaBuilt) Arena.build(sl);
        Economy.Stats st = eco.stats(p.getUUID());
        st.name = p.getGameProfile().getName();
        st.bot = false;
        if (st.base < 0 && eco.claim(p.getUUID()) < 0) {
            kickBot(sl, eco);
            eco.claim(p.getUUID());
        }
        boolean first = !st.kit;
        if (first) {
            st.kit = true;
            st.money = 150;
            p.getInventory().add(new ItemStack(EggSteal.BAT.get()));
        }
        eco.setDirty();
        Shop.applySpeed(p, st);
        if (st.base >= 0 && (first || !inArena(p.getX(), p.getZ()) || p.getY() < 55)) {
            Vec3 h = Arena.home(st.base);
            p.teleportTo(sl, h.x, h.y + 1, h.z, 0f, 0f);
        }
        p.sendSystemMessage(Component.literal("§6Welcome to Egg Steal! §7Buy eggs by right-clicking your conveyor belt next to an egg, right-click an egg on your base to hatch it, steal from others, and upgrade with /eggsteal shop"));
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Economy.Stats st = Economy.get(p.server).stats(p.getUUID());
        if (st.base >= 0) {
            Vec3 h = Arena.home(st.base);
            p.teleportTo(p.server.overworld(), h.x, h.y + 1, h.z, 0f, 0f);
        }
    }

    static void kickBot(ServerLevel sl, Economy eco) {
        for (Map.Entry<UUID, Economy.Stats> en : new ArrayList<>(eco.map.entrySet())) {
            if (!en.getValue().bot || en.getValue().base < 0) continue;
            UUID id = en.getKey();
            Entity b = sl.getEntity(id);
            if (b != null) b.discard();
            for (CreatureEntity c : sl.getEntities(net.minecraft.world.level.entity.EntityTypeTest.forClass(CreatureEntity.class), x -> id.equals(x.owner()))) c.discard();
            eco.release(id);
            return;
        }
    }

    @SubscribeEvent
    public static void tick(ServerTickEvent.Post e) {
        MinecraftServer s = e.getServer();
        Economy eco = Economy.get(s);
        if (!eco.arenaBuilt) return;
        int t = s.getTickCount();
        Belt.tick(s.overworld(), eco);
        if (t % 20 == 0) Hud.actionbar(s);
        if (t % 100 == 0) {
            manageBots(s, eco);
            Hud.leaderboard(s);
        }
    }

    static void manageBots(MinecraftServer s, Economy eco) {
        ServerLevel sl = s.overworld();
        int bots = 0;
        for (Map.Entry<UUID, Economy.Stats> en : new ArrayList<>(eco.map.entrySet())) {
            Economy.Stats st = en.getValue();
            if (st.bot && st.base >= 0) {
                bots++;
                if (s.getTickCount() > 400 && sl.getEntity(en.getKey()) == null) spawnBot(sl, en.getKey(), st);
            }
        }
        if (bots < BOT_COUNT && s.getTickCount() > 100) {
            UUID id = UUID.randomUUID();
            if (eco.claim(id) < 0) return;
            Economy.Stats st = eco.stats(id);
            st.bot = true;
            st.money = 100;
            st.name = NAMES[bots % NAMES.length];
            for (Economy.Stats o : eco.map.values()) if (o != st && o.name.equals(st.name)) st.name = st.name + (int) (Math.random() * 90 + 10);
            eco.setDirty();
            spawnBot(sl, id, st);
        }
    }

    static void spawnBot(ServerLevel sl, UUID id, Economy.Stats st) {
        BotEntity b = EggSteal.BOT.get().create(sl);
        if (b == null) return;
        b.setUUID(id);
        Vec3 h = Arena.home(st.base);
        b.moveTo(h.x, h.y, h.z, 0f, 0f);
        sl.addFreshEntity(b);
    }

    /** Right-click your own conveyor belt (the block next to an egg) to buy that egg. */
    @SubscribeEvent
    public static void beltClick(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return;
        Economy eco = Economy.get(p.server);
        Economy.Stats st = eco.stats(p.getUUID());
        if (st.base < 0) return;
        BlockPos bp = e.getPos();
        if (bp.getY() != 63 || Math.abs(bp.getX() - Arena.cx(st.base)) > 10 || Math.abs(bp.getZ() - Arena.beltZ(st.base)) > 1) return;
        ServerLevel sl = (ServerLevel) e.getLevel();
        ItemEntity best = null;
        double bd = 3.0;
        for (ItemEntity ie : sl.getEntitiesOfClass(ItemEntity.class, Belt.box(st.base), it -> it.getPersistentData().contains("es_belt"))) {
            double d = Math.abs(ie.getX() - (bp.getX() + 0.5));
            if (d < bd) { bd = d; best = ie; }
        }
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
        if (best == null) { p.displayClientMessage(Component.literal("§7No egg here - click the belt right next to an egg."), true); return; }
        Creature c = Creature.VALUES[best.getPersistentData().getInt("es_belt")];
        if (st.money < c.price) {
            p.displayClientMessage(Component.literal("§cNot enough money! Need $" + Economy.fmt(c.price)), true);
            return;
        }
        st.money -= c.price;
        eco.setDirty();
        best.discard();
        ItemStack egg = Steal.makeEgg(c.ordinal(), null);
        if (!p.getInventory().add(egg)) p.drop(egg, false);
        p.displayClientMessage(Component.literal("§aBought " + c.tag() + " §aegg! Right-click it on your base to hatch."), true);
    }

    @SubscribeEvent
    public static void hurt(LivingIncomingDamageEvent e) {
        if (e.getEntity().level().isClientSide) return;
        if (e.getSource().getEntity() instanceof LivingEntity attacker) Steal.onHit(e.getEntity(), attacker);
    }

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (!e.getPlayer().isCreative() && inArena(e.getPos().getX(), e.getPos().getZ())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void placeBlock(BlockEvent.EntityPlaceEvent e) {
        if (e.getEntity() instanceof Player p && !p.isCreative() && inArena(e.getPos().getX(), e.getPos().getZ())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("eggsteal")
                .then(Commands.literal("shop").executes(c -> { Shop.show(c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("buy").then(Commands.argument("what", StringArgumentType.word()).executes(c -> {
                    Shop.buy(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "what"));
                    return 1;
                })))
                .then(Commands.literal("home").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Economy.Stats st = Economy.get(p.server).stats(p.getUUID());
                    if (st.base >= 0) { Vec3 h = Arena.home(st.base); p.teleportTo(p.server.overworld(), h.x, h.y + 1, h.z, 0f, 0f); }
                    return 1;
                }))
                .then(Commands.literal("top").executes(c -> { Hud.leaderboard(c.getSource().getServer()); return 1; }))
                .then(Commands.literal("arena").requires(s -> s.hasPermission(2)).executes(c -> {
                    Arena.build(c.getSource().getServer().overworld());
                    return 1;
                })));
    }
}
