package com.eggsteal;

import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.Vec3;

/**
 * A bot that plays the game by itself: upgrades itself and its belt, buys eggs off its belt,
 * hatches them in its base, and sneaks out to steal creatures from other bases.
 */
public class BotEntity extends PathfinderMob {
    public int carried = -1;
    public UUID carriedFrom;
    private int phase, phaseTicks, chase;
    private UUID goal;

    public BotEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 100).add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 1.0).add(Attributes.FOLLOW_RANGE, 48);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25, true));
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }

    public void aggro(LivingEntity thief) {
        setTarget(thief);
        chase = 0;
    }

    /** A recovered creature goes straight back into this bot's base. */
    public void receive(int variant) {
        if (!(level() instanceof ServerLevel sl)) return;
        Economy eco = Economy.get(sl.getServer());
        Economy.Stats st = eco.stats(getUUID());
        if (!Arena.place(sl, getUUID(), variant, st)) { st.money += Creature.VALUES[variant].price * 0.5; eco.setDirty(); }
    }

    private void applySpeed(Economy.Stats st) {
        var a = getAttribute(Attributes.MOVEMENT_SPEED);
        if (a != null) a.setBaseValue(0.25 * (1 + 0.08 * st.speed));
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel sl)) return;
        if (getMainHandItem().isEmpty()) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(EggSteal.BAT.get()));
            setDropChance(EquipmentSlot.MAINHAND, 0f);
        }
        if (tickCount % 20 == 0) heal(5);
        Economy eco = Economy.get(sl.getServer());
        Economy.Stats st = eco.stats(getUUID());
        st.bot = true;
        if (tickCount % 40 == 0) {
            applySpeed(st);
            setCustomName(Component.literal("§b" + st.name + " §a$" + Economy.fmt(st.money)));
            setCustomNameVisible(true);
        }
        if (getTarget() != null) {
            if (++chase > 300 || !getTarget().isAlive()) { setTarget(null); chase = 0; }
            return;
        }
        if (tickCount % 10 != 0 || st.base < 0) return;
        phaseTicks += 10;
        if (phaseTicks > 900) { phase = carried >= 0 ? 2 : 0; phaseTicks = 0; }
        switch (phase) {
            case 0 -> idle(sl, eco, st);
            case 1 -> toBelt(sl, eco, st);
            case 2 -> goHome(sl, eco, st);
            case 3 -> toVictim(sl);
        }
    }

    private void idle(ServerLevel sl, Economy eco, Economy.Stats st) {
        if (carried >= 0) { phase = 2; phaseTicks = 0; return; }
        int avail = Arena.available(st);
        int owned = Arena.owned(sl, getUUID());
        Economy.Upgrade best = null;
        double bc = Double.MAX_VALUE;
        for (Economy.Upgrade u : Economy.Upgrade.values()) {
            int lv = u.level(st);
            if (lv >= u.max) continue;
            if (u == Economy.Upgrade.SLOTS && owned < avail) continue;
            double c = u.cost(lv);
            if (c < bc) { bc = c; best = u; }
        }
        if (best != null && st.money >= bc && (owned >= avail || random.nextFloat() < 0.5f)) {
            st.money -= bc;
            best.set(st, best.level(st) + 1);
            eco.setDirty();
            applySpeed(st);
            return;
        }
        if (owned < avail) {
            ItemEntity egg = null;
            double bp = -1;
            for (ItemEntity e : sl.getEntitiesOfClass(ItemEntity.class, Belt.box(st.base), it -> it.getPersistentData().contains("es_belt"))) {
                double pr = Creature.VALUES[e.getPersistentData().getInt("es_belt")].price;
                if (pr <= st.money && pr > bp) { bp = pr; egg = e; }
            }
            if (egg != null) { goal = egg.getUUID(); phase = 1; phaseTicks = 0; return; }
        }
        if (random.nextFloat() < 0.3f) {
            List<? extends CreatureEntity> all = sl.getEntities(EntityTypeTest.forClass(CreatureEntity.class),
                    c -> c.owner() != null && !c.owner().equals(getUUID()) && !c.hatching());
            if (!all.isEmpty()) {
                goal = all.get(random.nextInt(all.size())).getUUID();
                phase = 3;
                phaseTicks = 0;
            }
        }
    }

    private void toBelt(ServerLevel sl, Economy eco, Economy.Stats st) {
        Entity e = goal == null ? null : sl.getEntity(goal);
        if (!(e instanceof ItemEntity ie) || !ie.isAlive()) { phase = 0; return; }
        if (distanceToSqr(ie) < 5) {
            Creature c = Creature.VALUES[ie.getPersistentData().getInt("es_belt")];
            if (st.money >= c.price) {
                st.money -= c.price;
                carried = c.ordinal();
                carriedFrom = null;
                ie.discard();
                eco.setDirty();
                phase = 2;
                phaseTicks = 0;
            } else phase = 0;
            return;
        }
        getNavigation().moveTo(ie, 1.0);
    }

    private void goHome(ServerLevel sl, Economy eco, Economy.Stats st) {
        if (carried < 0) { phase = 0; return; }
        int idx = Arena.freeSlot(sl, st.base, Arena.available(st));
        if (idx < 0) {
            st.money += Creature.VALUES[carried].price * 0.5;
            carried = -1;
            carriedFrom = null;
            eco.setDirty();
            phase = 0;
            return;
        }
        Vec3 p = Arena.slot(st.base, idx);
        if (position().distanceToSqr(p.x, p.y, p.z) < 9) {
            Arena.spawnCreature(sl, getUUID(), carried, st.base, idx);
            carried = -1;
            carriedFrom = null;
            phase = 0;
            return;
        }
        getNavigation().moveTo(p.x, p.y, p.z, 1.15);
    }

    private void toVictim(ServerLevel sl) {
        Entity e = goal == null ? null : sl.getEntity(goal);
        if (!(e instanceof CreatureEntity c) || !c.isAlive() || c.hatching() || getUUID().equals(c.owner())) { phase = 0; return; }
        if (distanceToSqr(c) < 5) {
            carried = c.variant();
            carriedFrom = c.owner();
            UUID from = c.owner();
            c.discard();
            Steal.notifyVictim(sl, from, this, carried);
            phase = 2;
            phaseTicks = 0;
            return;
        }
        getNavigation().moveTo(c, 1.1);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("carried", carried);
        if (carriedFrom != null) t.putUUID("from", carriedFrom);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        carried = t.contains("carried") ? t.getInt("carried") : -1;
        if (t.hasUUID("from")) carriedFrom = t.getUUID("from");
    }
}
