package com.eggsteal;

import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class Shop {
    static final ResourceLocation SPEED_ID = ResourceLocation.fromNamespaceAndPath(EggSteal.MODID, "shop_speed");

    public static void applySpeed(ServerPlayer p, Economy.Stats st) {
        AttributeInstance a = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (a == null) return;
        a.removeModifier(SPEED_ID);
        if (st.speed > 0) a.addTransientModifier(new AttributeModifier(SPEED_ID, 0.08 * st.speed, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    public static void show(ServerPlayer p) {
        Economy eco = Economy.get(p.server);
        Economy.Stats st = eco.stats(p.getUUID());
        p.sendSystemMessage(Component.literal("§6§l=== EGG STEAL SHOP ===  §a$" + Economy.fmt(st.money)));
        for (Economy.Upgrade u : Economy.Upgrade.values()) {
            int lv = u.level(st);
            Component line;
            if (lv >= u.max) line = Component.literal("§e" + u.label + " §7Lv" + lv + " §c[MAX]");
            else {
                double cost = u.cost(lv);
                line = Component.literal("§e" + u.label + " §7Lv" + lv + "/" + u.max + " ")
                        .append(Component.literal((st.money >= cost ? "§a" : "§c") + "[Buy $" + Economy.fmt(cost) + "]")
                                .withStyle(s -> s.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/eggsteal buy " + u.id))));
            }
            p.sendSystemMessage(line);
        }
    }

    public static void buy(ServerPlayer p, String what) {
        Economy.Upgrade u = Economy.Upgrade.byId(what);
        if (u == null) { p.sendSystemMessage(Component.literal("§cUnknown upgrade. Use: speed, income, belt, slots")); return; }
        Economy eco = Economy.get(p.server);
        Economy.Stats st = eco.stats(p.getUUID());
        int lv = u.level(st);
        if (lv >= u.max) { p.sendSystemMessage(Component.literal("§cAlready at max level.")); return; }
        double cost = u.cost(lv);
        if (st.money < cost) { p.sendSystemMessage(Component.literal("§cNot enough money. Need $" + Economy.fmt(cost))); return; }
        st.money -= cost;
        u.set(st, lv + 1);
        eco.setDirty();
        applySpeed(p, st);
        p.sendSystemMessage(Component.literal("§a" + u.label + " upgraded to Lv" + (lv + 1) + "!"));
    }
}
